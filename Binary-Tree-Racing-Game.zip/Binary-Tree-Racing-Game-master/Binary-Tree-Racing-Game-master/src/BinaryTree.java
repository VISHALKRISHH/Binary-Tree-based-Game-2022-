import java.util.Random;
class Node{
	int number;
	Node left;
	Node right;
}

public class BinaryTree {
	static Random r;
	Node n;
	BinaryTree(){
		r = new Random();
		n = createTree(n, 0, 1, 1);
	}
	public static Node createTree(Node parent, int depth, int data, int choice) {
		//If choice get 0 then no node else if 1 or 2 then make new node 
		//This is done to increase the probability of creating node
		
		
		if(depth != 5) { //IF THE DEPTH IS NOT EQUALTO 5

			if(choice == 0)  { //when choice == 0 then don't create a node
				return null;
			}
			else {
				parent = new Node();
				parent.number = data;//if choice == 1 OR 2 then create new node	1/3 and 2/3 chances of no node or a node respectively.
				parent.left = createTree(parent.left,depth+1,data*2, r.nextInt(3));//TO CREATE THE LEFT NODE OF THE PARENT 
				parent.right = createTree(parent.right,depth+1,data*2+1, r.nextInt(3));//TO CREATE THE RIGHT NODE OF THE PARENT 
				return parent;
			}
		}
		else {
			return null;
		}
	}
	//TRAVERSE THE NODE OF THE TREE
	public static void traverse(Node parent, NodeG dispNode) {
		System.out.println(parent.number);
		dispNode.label.setVisible(true);
		//LEFT NODE OF THE PARENT IS NOT EQUAL THEN IT WILL PRINT 
		if(parent.left != null) {
			traverse(parent.left,dispNode.left);
		}
		//RIGHT NODE OF THE PARENT IS NOT EQUAL THEN IT WILL PRINT 
		if(parent.right != null) {
			traverse(parent.right,dispNode.right);
		}
	}
}
