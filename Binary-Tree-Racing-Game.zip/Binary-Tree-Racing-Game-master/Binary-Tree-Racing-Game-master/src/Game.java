
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JToggleButton;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class Game {
	//References
	private JFrame Race; // INITIALIZING THE JFRAME
	private NodeG dispNode; 
	JRadioButton leftRB1;// INITIALIZING THE JRADIOBUTTON (LEFT) FOR PLAYER-1
	JRadioButton rightRB1;// INITIALIZING THE JRADIOBUTTON (RIGJT) FOR PLAYER-1
	JRadioButton leftRB2;// INITIALIZING THE JRADIOBUTTON (LEFT) FOR PLAYER-2
	JRadioButton rightRB2;// INITIALIZING THE JRADIOBUTTON (RIGHT) FOR PLAYER-2
	JLabel lblforp1;// INITIALIZING THE JLABEL FOR PLAYER-1 
	JLabel lblforp2;// INITIALIZING THE JLABEL FOR PLAYER - 2
	JLabel posShow1;// INITIALIZING THE JLABEL TO SHOW THE POSOTION OF PLAYER -1
	JLabel posShow2;// INITIALIZING THE JLABEL TO SHOW THE POSOTION OF PLAYER -1
	JButton moveButton;// INITIALIZING THE JBUTTON
	ButtonGroup g1;// INITIALIZING THE JBUTTON
	ButtonGroup g2;// INITIALIZING THE JBUTTON
	JLabel depth1;// INITIALIZING THE JLABEL TELLING THE DEPTH FOR PLAYER-1
	JLabel depth2;// INITIALIZING THE JLABEL TELLING THE DEPTH FOR PLAYER-2
	
	BinaryTree tree; // INITIALIZING THE BINARY TREE
	Node p1;//INITIALIZING THE NODE FOR PLAYER-1
	Node p2;//INITIALIZING THE NODE FOR PLAYER-2
	NodeG pd1;//INITIALIZING THE NODE FOR PLAYER-1
	NodeG pd2;//INITIALIZING THE NODE FOR PLAYER-2
	private JLabel message;//INITIALIZING JLABEL FOR DISPLAYING MESSAGE
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() { //IT RUNS UNDERLYING PEER CLASSES & TRUSTED APPLICATION CLASSES
			public void run() {
				try {
					Game window = new Game();
					window.Race.setVisible(true); // OPENING THE GUI WINDOW
				} catch (Exception e) {
					e.printStackTrace(); // IT DIAGONES THE EXCEPTION
				}
			}
		}); 
	}

	/**
	 * Create the application.
	 */
	public Game() {
		// POPING UP THE FIRST WINDOW TO DISPLAY THE MESSAGE
		JOptionPane.showMessageDialog(null, "This is the two player game in which the player, who can go into more depth of the binary tree can win the game",
	               "Welcome",1);
		
		// CALLING THE MAIN GAME WINDOW 
		Race = new JFrame();
		Race.setTitle("Binary Tree Race Game By Team 10 "); // SETTING THE MAIN GAME WINDOW NAME
		
		tree = new BinaryTree();
		BinaryTreeGui BTree = new BinaryTreeGui(Race); // CALLING THE BinaryTreeGui.java (CLASS)
		dispNode = new NodeG();
		dispNode = BTree.createTree(dispNode, 0, 1, 800, 150); // ALLIGNING THE STRUCTURE OF FIRST NODE FOR TREE
		dispNode.label.setVisible(true);// IT SET VISIBLE TRUE - TO DISPLAY THE CONTENT
		initialize();
//		tree.traverse(tree.n, dispNode);
		p1 = tree.n;
		p2 = tree.n;
		pd1 = dispNode;
		pd2 = dispNode;
		display();	
		
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		Race.setBounds(100, 100, 1277, 656); // SETTING THE POSITION AND THE SIZE OF THE BUTTON
		Race.setExtendedState(JFrame.MAXIMIZED_BOTH); // SETTING THE FRAME TO BE AT MAXIMIZED SIZE
		Race.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // SETTING TO CLOSE THE APPLICATION BY CLICKING THE CLOSE WINDOW
		Race.getContentPane().setLayout(null); // ADDING THE PROPERTIES TO THE FRAME
		
		// player -1 
		leftRB1 = new JRadioButton("LEFT"); // CREATING A JRADIOBUTTON
		leftRB1.setFont(new Font("Tahoma", Font.PLAIN, 15));// SETTING FONT FOR THE CONTENT 
		leftRB1.setBounds(64, 239, 111, 23);// SETTING SIZE OF THE BUTTON
		Race.getContentPane().add(leftRB1);// ADDING THE PROPERTIES TO THE FRAME
		
		rightRB1 = new JRadioButton("RIGHT");// CREATING A JRADIOBUTTON
		rightRB1.setFont(new Font("Tahoma", Font.PLAIN, 15));// SETTING FONT FOR THE CONTENT 
		rightRB1.setBounds(64, 265, 111, 23);// SETTING SIZE OF THE BUTTON
		Race.getContentPane().add(rightRB1);// ADDING THE PROPERTIES TO THE FRAME
		
		lblforp1 = new JLabel("Player 1 is at Node "); // SETTING THE LABEL FOR PLAYER -1
		lblforp1.setFont(new Font("Tahoma", Font.PLAIN, 20));// SETTING FONT FOR THE CONTENT
		lblforp1.setBounds(64, 203, 172, 23);// SETTING SIZE OF THE LABEL
		Race.getContentPane().add(lblforp1);// ADDING THE PROPERTIES TO THE FRAME
		
		posShow1 = new JLabel("1");// SETTING LABEL FOR PLAYER - 1 IN THE GAME BOARD
		posShow1.setOpaque(true);// SETTING THE BOX AS OPAQUE
		posShow1.setBackground(Color.BLACK);// BACKGROUND COLOUR AS BLACK
		posShow1.setForeground(Color.WHITE);// FOREGROUND COLOUR AS WHITE
		posShow1.setHorizontalAlignment(SwingConstants.CENTER);// SETTING THE LABEL TO BE IN CENTRE
		posShow1.setFont(new Font("Tahoma", Font.PLAIN, 26));// SETTING THE FORNT
		posShow1.setBounds(246, 201, 45, 23);// SETTING THE SIZE
		Race.getContentPane().add(posShow1);// ADDING THE PROPERTIES TO THE FRAME
		
		// player -2 
		lblforp2 = new JLabel("Player 2 is at Node ");// SETTING THE LABEL FOR PLAYER -2
		lblforp2.setFont(new Font("Tahoma", Font.PLAIN, 20));// SETTING FONT FOR THE CONTENT
		lblforp2.setBounds(64, 375, 172, 23);// SETTING SIZE OF THE LABEL
		Race.getContentPane().add(lblforp2);// ADDING THE PROPERTIES TO THE FRAME
		
		posShow2 = new JLabel("1");// SETTING LABEL FOR PLAYER - 1 IN THE GAME BOARD
		posShow2.setOpaque(true);// SETTING THE BOX AS OPAQUE
		posShow2.setHorizontalAlignment(SwingConstants.CENTER);// SETTING THE LABEL TO BE IN CENTRE
		posShow2.setForeground(Color.WHITE);// FOREGROUND COLOUR AS WHITE
		posShow2.setFont(new Font("Tahoma", Font.PLAIN, 26));// SETTING THE FORNT
		posShow2.setBackground(Color.blue);// BACKGROUND COLOUR AS BLUE
		posShow2.setBounds(246, 373, 45, 23);// SETTING SIZE OF THE LABEL
		Race.getContentPane().add(posShow2);// ADDING THE PROPERTIES TO THE FRAME
		
		leftRB2 = new JRadioButton("LEFT");// CREATING A JRADIOBUTTON
		leftRB2.setFont(new Font("Tahoma", Font.PLAIN, 15));// SETTING FONT FOR THE CONTENT 
		leftRB2.setBounds(64, 411, 111, 23);// SETTING SIZE OF THE BUTTON
		Race.getContentPane().add(leftRB2);// ADDING THE PROPERTIES TO THE FRAME
		
		rightRB2 = new JRadioButton("RIGHT");// CREATING A JRADIOBUTTON
		rightRB2.setFont(new Font("Tahoma", Font.PLAIN, 15));// SETTING FONT FOR THE CONTENT 
		rightRB2.setBounds(64, 437, 111, 23);// SETTING SIZE OF THE BUTTON
		Race.getContentPane().add(rightRB2);// ADDING THE PROPERTIES TO THE FRAME
		
		// Move
		moveButton = new JButton("Move");// CREATING A JRADIOBUTTON
		moveButton.setFont(new Font("Tahoma", Font.PLAIN, 27));// SETTING FONT FOR THE CONTENT
		moveButton.setBounds(64, 520, 227, 51);// SETTING SIZE OF THE BUTTON
		Race.getContentPane().add(moveButton);// ADDING THE PROPERTIES TO THE FRAME
		
		g1 = new ButtonGroup();
		g1.add(leftRB1);// ADDING LEFT BUTTON OF PLAYER 1
		g1.add(rightRB1);// ADDING RIGHT BUTTION FOR PLAYER 1
		
		g2 = new ButtonGroup();
		g2.add(leftRB2);// ADDING LEFT BUTTION FOR PLAYER 2
		g2.add(rightRB2);// ADDING RIGHT BUTTION FOR PLAYER 2
		
		JLabel lblNewLabel_1 = new JLabel("depth : ");//SETTING THE LABEL
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));// SETTING FONT FOR THE CONTENT
		lblNewLabel_1.setBounds(64, 297, 54, 23);// SETTING SIZE OF THE FONT
		Race.getContentPane().add(lblNewLabel_1);// ADDING THE PROPERTIES TO THE FRAME
		
		depth1 = new JLabel("0");//SETTING THE LABEL
		depth1.setFont(new Font("Tahoma", Font.BOLD, 18));// SETTING FONT FOR THE CONTENT
		depth1.setBounds(128, 297, 54, 23);// SETTING SIZE OF THE FONT
		Race.getContentPane().add(depth1);// ADDING THE PROPERTIES TO THE FRAME
		
		JLabel lblNewLabel_1_1 = new JLabel("depth : ");//SETTING THE LABEL
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));// SETTING FONT FOR THE CONTENT
		lblNewLabel_1_1.setBounds(64, 467, 54, 23);// SETTING SIZE OF THE FONT
		Race.getContentPane().add(lblNewLabel_1_1);// ADDING THE PROPERTIES TO THE FRAME
		
		depth2 = new JLabel("0");//SETTING THE LABEL
		depth2.setFont(new Font("Tahoma", Font.BOLD, 18));// SETTING FONT FOR THE CONTENT
		depth2.setBounds(128, 467, 54, 23);// SETTING SIZE OF THE FONT
		Race.getContentPane().add(depth2);// ADDING THE PROPERTIES TO THE FRAME
		
		message = new JLabel("");//SETTING THE LABEL
		message.setFont(new Font("Tahoma", Font.PLAIN, 30));// SETTING FONT FOR THE CONTENT
		message.setBounds(64, 125, 430, 45);// SETTING SIZE OF THE FONT
		Race.getContentPane().add(message);// ADDING THE PROPERTIES TO THE FRAME
		
		JLabel lblNewLabel_2 = new JLabel("");//SETTING THE LABEL
		lblNewLabel_2.setBounds(522, 28, 546, 106);// SETTING SIZE OF THE FONT
		Race.getContentPane().add(lblNewLabel_2);// ADDING THE PROPERTIES TO THE FRAME
		
		moveButton.addActionListener(new ActionListener() {// WORKING OF THE BUTTON
			public void actionPerformed(ActionEvent e) {
				// SETTING THE CONDITION FOR THE GUI TO WORK
				// BOTH PLAYER HAS TO SELECT THE PATHE TO TRAVEL WHEN GIVEN TO CHOOSE
				try {
					if(((leftRB1.isSelected() || rightRB1.isSelected()) && 
							(leftRB2.isSelected() || rightRB2.isSelected())) ||
							(!leftRB1.isVisible() && !rightRB1.isVisible()) ||
							(!leftRB2.isVisible() && !rightRB2.isVisible()) ) {
						gameplay();
						display();
						
						
					}
					// IF BOTH PLAYERS DIDN'T CHOOSE OR EITHER ONE PLAYER DIDN'T CHOOSE IT THROWS EXCEPTION
					else {
						throw new Exception();
					}
				}
				// WHEN IT THROWS EXCEPTION IT DISPLAYS THE ERROR MESSOGE 
				catch(Exception e1) {
					JOptionPane.showMessageDialog(Race, "Both player should select the path!",
				               "Can't Move", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
	}
	
	// TO CALCULATE THE DEPTH OF THE TREE BY INCREMENTING 
	public static void incDepth(JLabel l) {
		int d = Integer.parseInt(l.getText()); // CHARACTER TO INTEGER
		d++; // INCREMENT
		l.setText(Integer.toString(d));// INTEGER TO CHARACTER
	}
	public void gameplay() {
		//Conditions for moving player 1
		if(leftRB1.isSelected()) { // IF PLAYER 1 CLICKING LEFT BUTTON
			pd1 = pd1.left;
			p1 = p1.left;
			posShow1.setText(pd1.label.getText());
			incDepth(depth1);//INCREMENT THE DEPTH OF THE PLAYER 1
		}
		else if(rightRB1.isSelected()) {  // IF PLAYER 1 CLICKING RIGHT BUTTON
			pd1 = pd1.right;
			p1 = p1.right;
			posShow1.setText(pd1.label.getText());
			incDepth(depth1);//INCREMENT THE DEPTH OF THE PLAYER 1
		}
		if(leftRB2.isSelected()) { // IF PLAYER 2 CLICKING LEFT BUTTON
			pd2 = pd2.left;
			p2 = p2.left;
			posShow2.setText(pd2.label.getText());
			incDepth(depth2); //INCREMENT THE DEPTH OF THE PLAYER 2
		}
		else if(rightRB2.isSelected()) { // IF PLAYER 2 CLICKING RIGHT BUTTON
			pd2 = pd2.right;
			p2 = p2.right;
			posShow2.setText(pd2.label.getText());
			incDepth(depth2);//INCREMENT THE DEPTH OF THE PLAYER 2
		}
		g1.clearSelection();//IT WILL CLEAR THE DEPTH AFTER EACH INCREMENT OF THE PLAYER 1
		g2.clearSelection();//IT WILL CLEAR THE DEPTH AFTER EACH INCREMENT OF THE PLAYER 2
		
	}
	public static boolean isGreaterThan(JLabel l1 , JLabel l2) {
		int c = Integer.parseInt(l1.getText());//
		int d = Integer.parseInt(l2.getText());//
		return c > d;
	}
	public void display(){ //TO DISPLAY
		
		if(pd1.label.getText().equals(pd2.label.getText())) {	//then pd1==pd2 points at some gui node
			pd1.label.setBackground(Color.red); //AT THE FIRST STEP OF THE GAME
			pd1.label.setForeground(Color.WHITE);
		}else {
			if(pd1.label.getText().equals(Integer.toString(p1.number)) ) {
				pd1.label.setOpaque(true);//IF PLAYER 1 CHANGES ITS POSITION IN TREE
				pd1.label.setBackground(Color.black);
				pd1.label.setForeground(Color.WHITE);
			}
			if(pd2.label.getText().equals(Integer.toString(p2.number))) {
				pd2.label.setBackground(Color.blue);//IF PLAYER 2 CHANGES ITS POSITION IN TREE
				pd2.label.setForeground(Color.WHITE);
			}
		}
		//Conditions to in display if there is way for p1
		if(p1.left != null) {
			pd1.left.label.setVisible(true);//THE CHILDREN WILL DISPLAY
			leftRB1.setVisible(true);
		}else {
			leftRB1.setVisible(false);//IT WONT DISPLAYED THE CHILDREN
		}
		if(p1.right != null) {
			pd1.right.label.setVisible(true);//THE CHILDREN WILL DISPLAY
			rightRB1.setVisible(true);
		}else {
			rightRB1.setVisible(false);//IT WONT DISPLAYED THE CHILDREN
		}
		//Conditions to in display if there is way for p2
		if(p2.left != null) {
			pd2.left.label.setVisible(true);//THE CHILDREN WILL DISPLAY
			leftRB2.setVisible(true);
		}else {
			leftRB2.setVisible(false);//IT WONT DISPLAYED THE CHILDREN
		}
		if(p2.right != null) {
			pd2.right.label.setVisible(true);//THE CHILDREN WILL DISPLAY
			rightRB2.setVisible(true);
		}else {
			rightRB2.setVisible(false);//IT WONT DISPLAYED THE CHILDREN
		}
		if(p2.left == null && p2.right == null &&
				p1.left == null && p1.right == null) {
					//DEPTH 1 > DEPTH 2 
			if(isGreaterThan(depth1,depth2)) {
				message.setText("Player 1 won the Game!");
				JOptionPane.showMessageDialog(null, "Player 1 won the Game!",
			               "Thanks for Playing",1);

			}
			      //DEPTH 2 > DEPTH 1
			else if(isGreaterThan(depth2,depth1)) {
				message.setText("Player 2 won the Game!");
				JOptionPane.showMessageDialog(null, "Player 2 won the Game!",
			               "Thanks for Playing",1);

			}
			//AFTER END OF THE GAME 
			else {
				JOptionPane.showMessageDialog(null, "DRAW Game!",
			               "Thanks for Playing",1);

				message.setText("Draw the Game!");
			}
			tree.traverse(tree.n, dispNode);

			//CLOSING POP UP WINDOW
			JOptionPane.showMessageDialog(null, "THANK YOU",
		               "HAVE A NICE DAY !!",1);
			
		}
	}
}
