# Binary-Tree-Racing-Game

## :page_facing_up:Project Descripttion
Binary Tree Racing Game which is a Multiplayer Game in JAVA with GUI applying Data Structures and Algorithm isn't it Amazing?

Let's start doing something entertaining in Data Structures by making a Multiplayer game in JAVA with GUI.

I used a binary tree in this game to clear the concepts of data structures and algorithm

This is an amazing project to clear the concepts of data structures and algorithms in an easy and entertaining way.
## :movie_camera:You can check out my video on my <a href="https://www.youtube.com/channel/TechnicalFarazOfficial">YouTube Channel</a>
[![Binary tree game](https://user-images.githubusercontent.com/60597399/115136719-864dde80-9fd6-11eb-9374-fd849bd08c39.jpg)](https://youtu.be/-jM1K9Amo6k)
<br>
## :blue_book:You can read its complete explanation on my article: https://technicalfaraz.com/binary-tree-game-in-java/

<br>

### :computer: For More Informative Material, Follow us on:
[<img align="left" alt="TechnicalFaraz.com" width="22px" src="https://raw.githubusercontent.com/iconic/open-iconic/master/svg/globe.svg" />][website]<a href="https://technicalfaraz.com/">TechnicalFaraz.com</a><br>
[<img align="left" alt="TechnicalFaraz | FacebookPage" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@3.13.0/icons/facebook.svg" />][facebook]<a href="https://www.facebook.com/technicalfaraz/">@TechnicalFaraz</a><br>
[<img align="left" alt="TechnicalFaraz | YouTube" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/youtube.svg" />][youtube]<a href="https://www.youtube.com/channel/TechnicalFarazOfficial">@TechnicalFarazOfficial</a>

<br>





### You can contact us at <a href="mailto:contact@technicalfaraz.com">Contact@TechnicalFaraz.com</a>
### Connect with me:

[<img align="left" alt="TechnicalFaraz | Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />][twitter]
[<img align="left" alt="TechnicalFaraz | LinkedIn" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />][linkedin]
[<img align="left" alt="TechnicalFaraz | Instagram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/instagram.svg" />][instagram]


<br />





[website]: https://technicalfaraz.com/
[twitter]: https://twitter.com/TechnicalFaraz5
[youtube]: https://www.youtube.com/channel/UCwO7fKd11Bg8YsL3bSPdcWQ
[facebook]: https://www.facebook.com/technicalfaraz/
[instagram]: https://www.instagram.com/technicalfaraz/
[linkedin]: https://www.linkedin.com/in/technicalfaraz/
